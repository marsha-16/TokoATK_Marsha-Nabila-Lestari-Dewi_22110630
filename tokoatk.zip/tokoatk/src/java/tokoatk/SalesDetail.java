/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tokoatk;

/**
 *
 * @author Marsha Nabila L
 */

import tokoatk.DbConnection;
import java.sql.*;
import java.util.ArrayList;

public class SalesDetail {
    private int id;
    private String salesId;
    private String barangId;
    private int qty;
    private int harga;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getSalesId() { return salesId; }
    public void setSalesId(String salesId) { this.salesId = salesId; }

    public String getBarangId() { return barangId; }
    public void setBarangId(String barangId) { this.barangId = barangId; }

    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; }

    public int getHarga() { return harga; }
    public void setHarga(int harga) { this.harga = harga; }

    public boolean tambah() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "INSERT INTO salesd (salesId, barangId, qty, harga) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, salesId);
            ps.setString(2, barangId);
            ps.setInt(3, qty);
            ps.setInt(4, harga);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ArrayList<SalesDetail> getList(String salesId) {
        ArrayList<SalesDetail> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM salesd WHERE salesId=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, salesId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SalesDetail d = new SalesDetail();
                d.setId(rs.getInt("id"));
                d.setSalesId(rs.getString("salesId"));
                d.setBarangId(rs.getString("barangId"));
                d.setQty(rs.getInt("qty"));
                d.setHarga(rs.getInt("harga"));
                list.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
