/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tokoatk;

/**
 *
 * @author Marsha Nabila L
 */

import tokoatk.DbConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class Sales {
    private String id;
    private LocalDateTime waktu;
    private String username;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public LocalDateTime getWaktu() { return waktu; }
    public void setWaktu(LocalDateTime waktu) { this.waktu = waktu; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public boolean tambah() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "INSERT INTO salesm (id, waktu, username) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setTimestamp(2, Timestamp.valueOf(waktu));
            ps.setString(3, username);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ArrayList<Sales> getList() {
        ArrayList<Sales> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM salesm ORDER BY waktu DESC");
            while (rs.next()) {
                Sales s = new Sales();
                s.setId(rs.getString("id"));
                s.setWaktu(rs.getTimestamp("waktu").toLocalDateTime());
                s.setUsername(rs.getString("username"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}