/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tokoatk;

/**
 *
 * @author Marsha Nabila L
 */

import tokoatk.DbConnection;
import java.sql.*;
import java.util.ArrayList;

public class StockDetail {
    private int id;
    private String stockId;
    private String barangId;
    private int qty;
    private int harga;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getStockId() { return stockId; }
    public void setStockId(String stockId) { this.stockId = stockId; }

    public String getBarangId() { return barangId; }
    public void setBarangId(String barangId) { this.barangId = barangId; }

    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; }

    public int getHarga() { return harga; }
    public void setHarga(int harga) { this.harga = harga; }

    public boolean tambah() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "INSERT INTO stockd (stockId, barangId, qty, harga) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, stockId);
            ps.setString(2, barangId);
            ps.setInt(3, qty);
            ps.setInt(4, harga);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ArrayList<StockDetail> getList(String stockId) {
        ArrayList<StockDetail> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockd WHERE stockId=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, stockId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                StockDetail d = new StockDetail();
                d.setId(rs.getInt("id"));
                d.setStockId(rs.getString("stockId"));
                d.setBarangId(rs.getString("barangId"));
                d.setQty(rs.getInt("qty"));
                d.setHarga(rs.getInt("harga"));
                list.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
